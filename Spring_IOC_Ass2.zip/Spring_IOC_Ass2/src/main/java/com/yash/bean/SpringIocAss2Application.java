package com.yash.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIocAss2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringIocAss2Application.class, args);
	}

}
