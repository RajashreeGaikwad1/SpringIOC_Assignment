package com.yash.model;

public class Supervisor implements Employee 
{
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Object of Supervisor class");
	}	

}
