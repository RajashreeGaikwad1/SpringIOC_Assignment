package com.yash.model;

public class Manager implements Employee
{
	@Override
	public void print()
	{
		// TODO Auto-generated method stub
		System.out.println("Object of Manager class ");
	}	

}
