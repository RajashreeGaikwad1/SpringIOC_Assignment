package com.yash.model;

public class Clerk implements Employee 
{
	@Override
	public void print() 
	{
		System.out.println("Object of Clerk class");	
		
	}

}
