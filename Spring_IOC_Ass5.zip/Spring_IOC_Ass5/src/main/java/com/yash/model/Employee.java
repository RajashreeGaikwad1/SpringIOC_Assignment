package com.yash.model;

public interface Employee 
{
	void print();
}
