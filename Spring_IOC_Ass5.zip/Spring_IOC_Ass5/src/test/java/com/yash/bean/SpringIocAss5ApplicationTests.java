package com.yash.bean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocAss5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
