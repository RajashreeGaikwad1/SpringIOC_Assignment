package com.yash.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIocAss6Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringIocAss6Application.class, args);
	}

}
