package com.yash.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EngineIocApplication {

	public static void main(String[] args) {
		ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationContext.xml"); 
		Vehicle objSCBean =(Vehicle) objAC.getBean("vehicle");
		
		 objSCBean.show();	
		 System.out.println();
		
	}

}
