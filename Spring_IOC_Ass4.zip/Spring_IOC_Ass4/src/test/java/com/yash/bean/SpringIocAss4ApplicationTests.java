package com.yash.bean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocAss4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
