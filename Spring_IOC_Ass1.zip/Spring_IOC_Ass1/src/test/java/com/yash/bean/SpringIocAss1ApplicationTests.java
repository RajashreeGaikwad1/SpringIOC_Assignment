package com.yash.bean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocAss1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
